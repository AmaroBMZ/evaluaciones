productos = {'C-123': ['HP', 15.6, '8GB', 'DD', '1T', 'Intel Core i5', 'Nvidia GTX1050'],
        'C-111': ['lenovo', 14, '4GB', 'SSD', '512GB', 'Intel Core i5', 'Nvidia GTX1050'],
        'C-234': ['Asus', 14, '16GB', 'SSD', '256GB', 'Intel Core i7', 'Nvidia RTX2080Ti'],
        'C-456': ['HP', 15.6, '8GB', 'DD', '1T', 'Intel Core i3', 'integrada'],
        'C-1222': ['Asus', 15.6, '8GB', 'DD', '1T', 'Intel Core i7', 'Nvidia GTX1050'],
        'C-477': ['lenovo', 14, '6GB', 'DD', '1T', 'AMD Ryzen 5', 'integrada'],
        'C-334': ['lenovo', 15.6, '8GB', 'DD', '1T', 'AMD Ryzen 7', 'Nvidia GTX1050'],
        'C-2906': ['Dell', 15.6, '8GB', 'DD', '1T', 'AMD Ryzen 3', 'Nvidia GTX1050']}

stock = {'C-123': [387990,10], 
        'C-111': [327990,4], 
        'C-234': [424990,1],
        'C-456': [664990,21], 
        'C-477': [290890,32], 
        'C-334': [444990,7],
        'C-1222': [749990,2], 
        'C-2906': [349990,1]}


def stock_marca(lst_productos:dict,lst_stock:dict,marca_buscada:str)->int:
        cant=0
        for codigo, datos in lst_productos.items():
                if datos[0].lower() == marca_buscada.lower():
                        cant+=lst_stock[codigo][1]
        return cant

def busqueda_precio(lst_productos:dict,lst_stock:dict,p_min:int,p_max:int)->None:
        print(f"Dentro del rango de {p_min} y {p_max} se encuentra:")
        for codigo,datos in lst_productos.items():
                if lst_stock[codigo][0]>=p_min and lst_stock[codigo][0]<=p_max:
                        print(f"|Codigo: {codigo}| Marca: {datos[0]}| Precio: {lst_stock[codigo][0]}")
                        print("-"*50)

def actualizar_precio(lst_stock:dict,codigo:str,nuevo_precio:int)->bool:
        if codigo in lst_stock:
                lst_stock[codigo][0]= nuevo_precio
                return True
        return False

def menu():
        while True:
                print("-"*50)
                print("1. Consultar stock total de una marca especifica")
                print("2. Buscar productos por rango de precio")
                print("3. Actualizar el precio de un producto")
                print("4. Salir")
                try:
                        opc=int(input("Ingrese una opcion: "))
                        print("-"*50)
                except ValueError:
                        print("Debe ingresar un número.")
                        print("-"*50)
                if opc == 1:
                        try:
                                marca= input("Que marca desea buscar: ").lower()
                                if len(marca) == 0:
                                        raise ValueError("La marca no puede estar vacía.")
                                cant=stock_marca(productos,stock,marca)
                                print(f"|Marca:{marca}| Stock total: {cant}")
                                print("-"*50)
                        except ValueError:
                                print("Error:vuelva a intentar")
                                print("-"*50)
                elif opc == 2:
                        p_min=int(input("Ingrese el precio minimo: "))
                        p_max=int(input("Ingrese el precio maximo: "))
                        if p_min < p_max:
                                busqueda_precio(productos,stock,p_min,p_max)
                        else:
                                print("El precio minimo no puede ser mayor o igual al precio maximo.")
                                print("-"*50)
                elif opc == 3:
                        try:
                                codigo=input("Ingrese el codigo del producto que desee actualizar: ")
                                if codigo not in stock:
                                        raise ValueError("El codigo ingresado no existe.")
                                nuevo_precio=int(input("Ingrese el precio que desea ponerle al producto: "))
                                if nuevo_precio < 0:
                                        raise ValueError("El precio no puede ser negativo.")
                                if actualizar_precio(stock,codigo,nuevo_precio):
                                        print("Se a actualizado el precio correctamente")
                                        print("-"*50)
                        except ValueError:
                                print("Error al actualizar el precio")
                                print("-"*50)
                elif opc == 4:
                        print("Saliendo del programa...")
                        break
                else:
                        print("ingrese una opción válida")
menu()